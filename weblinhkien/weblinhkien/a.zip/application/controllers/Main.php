<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Main extends CI_Controller{

    public function index(){
        $this->load->model('Type');
        $this->load->model('Products');
        $data = $this->Type->getAll();
        $products = $this->Products->getAll();        
        $count = 0;        
        $newProducts = array();
        for ($i=$this->Products->getNumRow()-1; $i >= 0 ; $i--) { 
            if ($count < 5) {
                $newProducts[$count] = $products[$i];
                $count ++;
            }else{
                break;
            }
        }
        $this->load->view("trangchu", array('type'=>$data, 'products'=>$products, 'newProducts'=>$newProducts));
    }
}