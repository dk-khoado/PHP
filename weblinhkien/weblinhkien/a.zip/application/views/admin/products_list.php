
<html>
<meta charset="utf-8">

<head>
	<title>Sản Phẩm</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap-4.3.1-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/datatables.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
	<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/datatables.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/popper.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/css/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/gijgo.min.js"></script>
</head>

<body class="container-fluid">
	<div class="row h-100">
		<!--Bảng điều hướng-->
		<div id="navbar" class="col-sm-2 bg-dark">
		<?php
			echo $nav;
		?>
		</div>
		<div class="col-sm-10 ">
			<!--HIỆN NÔI DUNG-->
			<!--Thanh MENU-->
			<nav class="navbar">
				<a class="nav-link" href="<?php echo site_url('admin/addProduct'); ?>"><button class="btn btn-dark">Thêm Sản Phẩm</button></a>
				
			</nav>
			<!--HIỆN BẢNG SẢN PHẨM-->
			<script type="text/javascript">
				$(document).ready(function() {
					$('#table').DataTable({
						"lengthChange": false,
						"lengthMenu": 10
					});
				});

				function confirmDelete() {
					if (confirm("Are you sure?")) {
						return true;
					} else
						return false;
				}
			</script>
			<table id="table" class="table table-bordered table-hover table-striped mt-3 shadow">
				<thead class="thead-dark">
					<tr>
						<th>Mã Sản Phẩm</th>
						<th>Tên Sản Phẩm</th>
						<th>Số Lượng</th>
						<th>Giá</th>
						<th>#</th>
					</tr>
				</thead>
				<tbody>
					<?php
					if ($list != null) {
						foreach ($list as $key => $valaue) {
							echo "<tr>";
							echo "<td>" . $valaue->CodeProduct . "</td>";
							echo "<td>" . $valaue->NameProduct . "</td>";
							echo "<td>" . $valaue->AmountProduct . "</td>";
							echo "<td>" . number_format($valaue->PriceProduct) . " VND</td>";
							echo "<td><a href='".site_url('admin/EditProduct/').$valaue->ID_PRODUCT."'>Edit | </a>
										<a href='".site_url('admin/deleteProduct/').$valaue->ID_PRODUCT. "' onclick='return confirmDelete()'>Delete</a>					
								</td>";
							echo "</tr>";
						}
					}
					?>
				</tbody>
			</table>

			<!--end-->
		</div>
</body>

</html>