
<div style="height: 100%">
<nav class="nav flex-column">
<img class="nav-item  rounded-circle mx-auto" src="../upload/image/logo.png" height="50px" width="50px">
<p class="nav-item text-white text-center" id="admin_name">khoa</p>
<hr>
<a class="nav-link" href="<?php echo site_url('admin/index'); ?>">Thống Kê</a>
<hr>
<a class="nav-link" href="<?php echo site_url('admin/product'); ?>">Sản Phẩm</a>
<a class="nav-link" href="<?php echo site_url('admin/Order'); ?>">Danh Sách đặt hàng</a>
<a class="nav-link" href="<?php echo site_url('admin/setup_page'); ?>">Tùy Chỉnh Trang</a>
<a class="nav-link" href="<?php echo site_url('admin/accout'); ?>">Khách Hàng</a>
<a class="nav-link" href="<?php echo site_url('admin/index'); ?>">Upload</a>
<hr>
<a class="nav-link" href="<?php echo site_url('admin/index'); ?>">Đăng Xuất</a>
</nav>
</div>