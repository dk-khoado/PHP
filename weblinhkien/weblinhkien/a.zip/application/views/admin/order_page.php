<html>
<meta charset="utf-8">

<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap-4.3.1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/datatables.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/gijgo.min.css">
    <script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/datatables.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/css/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/gijgo.min.js"></script>
</head>

<body class="container-fluid">
    <div class="row">
        <!-- phần navbar -->
        <div id="navbar" class="col-sm-2 bg-dark">
            <?php
            echo $nav;
            ?>
        </div>
        <div id="context" class="col-sm-10 ">
            <!--hiện chỉ số-->
            <script type="text/javascript">
                $(document).ready(function() {
                    $('#table').DataTable({
                        "lengthChange": false,
                        "lengthMenu": 10
                    });
                });
            </script>
            <table id="table" class="table table-striped table-bordered">
                <thead>
                    <th>Mã đơn hàng</th>
                    <th>Tên Người Đặt</th>
                    <th>Ngày Đặt</th>
                    <th>Trạng thái</th>
                    <th>#</th>
                </thead>
                <tbody>

                </tbody>
            </table>
            <!---->
        </div>
</body>

</html>